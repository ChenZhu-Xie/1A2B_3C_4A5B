//-----------------------------------------------------------------------------
// Main.c
//-----------------------------------------------------------------------------
// AUTH: ������.
// DATE: 2008/1/26
// ����˵������P2.0�˿ڽ��м򵥱��
//
//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include <c8051f350.h>                 // SFR declarations

//-----------------------------------------------------------------------------
// Global CONSTANTS
//-----------------------------------------------------------------------------
sbit LED20 = P2^0;                     // LED='1' means ON
sbit Pin01 = P0^1;                     // �˿�P0.1
//sbit RST4 = RSTSRC^4;                  // ������λ����SWRSFλ��RSTSRC.4��д��1��ǿ�Ʋ���һ��ϵͳ��λ

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void SYSCLK_Init();
void PORT_Init();
void Timer_Init();
void UART_Init();
void delayms(int time);

//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main() {
long lWaitSetting, lWaitCounter1, lWaitCounter2;       // Misc. counters
unsigned char Command0;
unsigned char TempChar1;
unsigned char cTest;

   // disable watchdog timer
   PCA0MD &= ~0x40;                       // WDTE = 0 (clear watchdog timer) 
                                          // WDTE = 1 (enable)
   SYSCLK_Init ();                        // Initialize system clock
   PORT_Init ();                          // Initialize crossbar and GPIO
   Timer_Init();
   UART_Init();
   delayms(200);

   lWaitSetting = 17500;      //175000 --> 1Hz
   lWaitSetting = 50000;      //175000 --> 1Hz
   lWaitCounter2 = lWaitSetting / 2;
   //IE = 0x80;      //���������ж�.

   RI0 = 0;

//TEST:
  while (RI0 == 0)  {
     lWaitCounter1++;
     if (lWaitCounter1 > lWaitSetting)   {
        lWaitCounter1 = 0;
     };

     if (lWaitCounter1 < lWaitCounter2)   {
        LED20 = 0;     //=0, ����!
     }
     else   {
        LED20 = 1;     //=1, Ϩ��!
     };
  };
  
//goto TEST;
  //RSTSRC = RSTSRC | 0x10;    //��SWRSFλ(RSTSRC.4)д1ǿ�Ʋ���һ��ϵͳ��λ..
}        //End of main()



//-----------------------------------------------------------------------------
//       SYSCLK_Init
// This routine initializes the system clock to use the internal 24.5MHz  
// oscillator as its clock source.  Also enables missing clock detector reset.
//-----------------------------------------------------------------------------
void SYSCLK_Init ()     {
   OSCICN = 0x83;            // configure internal oscillator 24.5MHz                                         // its lowest frequency
   RSTSRC = 0x04;            // enable missing clock detector
}


//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
void PORT_Init (void)   { //ʹ��LED��ʾ������.

  //P0MDOUT   = 0xFF;     //ȫ��������Ϊ���췽ʽ.
  P0MDOUT   = 0x30;     //P0.4, 0.5������Ϊ���췽ʽ.
  P0SKIP    = 0xCF;     //ֻ�������ڣ�����ȫ������������.
  //P1MDOUT   = 0x3F;     //0x3F�ճ���λ����DAC���ţ�ȫ��������Ϊ���췽ʽ.
  //P1SKIP    = 0x3F;
  P2MDOUT   = 0x01;

  XBR0     = 0x01;      //UART TX0,RX0�����˿�����P0.4 ��P0.5
  XBR1     = 0x40;      //���濪��ʹ��.
}

void Timer_Init()   {
   TMOD      = 0x21;         //01:��ʱ��0��Ϊ16λʱ��
                             //20:��ʱ��1��Ϊ�����ʷ�����,8λ�Զ���װ
}

void UART_Init()    {
   SCON0 = 0x10;             //SCON0: 8-bit variable bit rate
   TCON      = 0x40;
   //CKCON     = 0x01;       //��->9600      0x01->19200
   TH1       = 0x96;         //0x96->9600   0x61->19200
   TI0 = 1;  
     
   //19200BPS          
   //CKCON     = 0x08;
   //TH1       = 0xB1;
}

/////////////////////////////////////////////////////////////////////
//
//  Function: delayms(int)
// 
//  ˵����24MHz�ڲ�ʱ�������£���ʱ���뱶��.
//
/////////////////////////////////////////////////////////////////////
void delayms(int time)   {
unsigned char i, j;

  while (time>1)  {
     for(i=0; i<218; i++)   for(j=0; j<20; j++);
     time--;
  }
}
