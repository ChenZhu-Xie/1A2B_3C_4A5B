//-----------------------------------------------------------------------------
// Blinky.c
//-----------------------------------------------------------------------------
// Copyright 2004 Silicon Laboratories, Inc.
//
// AUTH: BD
// DATE: 06 FEB 04
//
// This program flashes the green LED on the C8051F35x target board about 
// five times a second using the interrupt handler for Timer2.
//
// Target: C8051F35x
//
// Tool chain: KEIL Eval 'c'
//

//-----------------------------------------------------------------------------
// Includes
//-----------------------------------------------------------------------------
#include <c8051f350.h>                    // SFR declarations
#include <math.h>

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F35x
//-----------------------------------------------------------------------------

sfr16 TMR2RL   = 0xca;                    // Timer2 reload value    ??
sfr16 TMR2     = 0xcc;                    // Timer2 counter      ??
/*
//-----------------------------------------------------------------------------
xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx                                                                           // Global CONSTANTS
//-----------------------------------------------------------------------------
*/
#define SYSCLK       24500000 / 8         // SYSCLK frequency in Hz
#define I	1
#define Kh  27

sbit LED0= P0^6;
sbit LED = P0^7;
sbit LED2=P0^3;                          // LED='1' means ON
sbit LM=P1^6;
sbit LN=P1^7;
sbit LL=P1^5; 
sbit P1_0=P1^0;			//��������ܵĵ�0λ
sbit P1_1=P1^1;			//��������ܵĵ�1λ
sbit P1_2=P1^2;			//��������ܵĵ�2λ
sbit P1_3=P1^3;			//��������ܵĵ�3λ
sbit P1_4=P1^4;			//��������ܵĵ�4λ
sbit P1_5=P1^5;			//��������ܵĵ�5λ


                 // SW2='0' means switch pressed

unsigned char ADCResult[5]={0,0,0,0,0};
unsigned char i=0;
unsigned char a=3;
unsigned char j=0;
unsigned int  time;
long int B_AD;		//���Ҫ��ʾ������
long int adc;
unsigned char  channel; //������ݱ�ʾС�����λ��
unsigned char b0;		//����������ʾ������;
unsigned char b1;
unsigned char b2;
unsigned char b3;
unsigned char b4;
unsigned char b5;

/******************************************************************************************
a              I/O�ڣ�          P0.7  P0.6  P0.5  P0.4  P0.3  P0.2  P0.1  P0.0
   ---            ����ܸ��Σ�      h     f     g     e     d     c     b     a
 f| g |b                   1��      0     0     0     0     0     1     1     0     0x06;
   ---                     2��      0     0     1     1     1     0     1     1     0x3B;
 e|   | c                  3��      0     0     1     0     1     1     1     1     0x2F;
   --- .h                  4��      0     1     1     0     0     1     1     0     0x66;
   d                       5��      0     1     1     0     1     1     0     1     0x6D;
                           6��      0     1     1     1     1     1     0     1     0x7D;
                           7��      0     0     0     0     0     1     1     1     0x07;
                           8��      0     1     1     1     1     1     1     1     0x7F;
                           9��      0     1     1     0     1     1     1     1     0x6F;
                           0��      0     1     0     1     1     1     1     1     0x5F;


*******************************************************************************************/
unsigned code TAB[] = {0x5F,0x06,0x3B,0x2F,0x66,0x6D,0x7D,0x07,0x7F,0x6F};
//0,   1,   2,   3,   4,   5,   6,   7,   8,   9  ;С���������λ;�����Ϊ������

//-----------------------------------------------------------------------------
// Function PROTOTYPES
//-----------------------------------------------------------------------------
void DAC_Init();
void SYSCLK_Init ();
void PORT_Init ();
void ADC_Init();
void ADC0_ISR ();
void Interrupts_Init();
//void Timer_Init();
void delay(int time);
//void UART_Init();
//void UART_ISR();
//void Comparator_Init();
//void Comparator_ISR();


//-----------------------------------------------------------------------------
// MAIN Routine
//-----------------------------------------------------------------------------
void main (void) 
{
// disable watchdog timer
   	PCA0MD &= ~0x40;                       // WDTE = 0 (clear watchdog timer �رտ��Ź�
                                          // enable)
	SYSCLK_Init ();                        // Initialize system clock
	PORT_Init ();                          // Initialize crossbar and GPIO
	ADC_Init();	
	Interrupts_Init();
	delay( time);                           
    AD0INT=0; 
 	DAC_Init(); 
	ADC0MD=0x83;                             //ADC0��ʽ�Ĵ��� 
	//P0=0;                              //ȫ��
	while (1) 
	{  
	//	delay(500);
	//	LL=~LL;
  	//	LED2=~LED2;    // spin forever
  	    b5=B_AD/100000;
  	    b4=(B_AD/10000)%10;
		b3=(B_AD/1000)%10;
		b2=(B_AD/100)%10;
		b1=(B_AD/10)%10;
		b0=B_AD%10;
	
		
		
		
		 //P0=0x12;         P1=0x2;    delay(5);
		 //P0=0x14;         P1=0x4;    delay(5);
		//P0=0x18;         P1=0x8;    delay(2);
		//P0=0x1F;         P1=0x10;   delay(2);
		//P0=0xFF;         P1=0x20;   delay(2);
		
                 
	//	switch(channel)
	//	{
	//	case 0:
	//	 P0=0x5F;		   P1=0x1;	  delay(5);
	//	 break;
    //     }
		 /*
			P0=TAB[b0];
			P1=1;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;
		case 1:
			P0=TAB[b0];
			P1=2;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;	
		case 2:
			P0=TAB[b0];
			P1=3;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;					
		case 3:
			P0=TAB[b0];
			P1=3;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;		
		case 4:
			P0=TAB[b0];
			P1=5;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;	
		case 5:
			P0=TAB[b0];
			P1=6;
			delay(2);
			P0=TAB[b1];    P1<<=1;   delay(1);
			P0=TAB[b2];    P1<<=1;   delay(1);
			P0=TAB[b3];    P1<<=1;   delay(1);
			P0=TAB[b4];    P1<<=1;   delay(1);
			P0=TAB[b5];    P1<<=1;   delay(1);
			break;		
		default:
			break;
		}*/
	}
}

void ADC0_ISR (void) interrupt 10      //??
{
	delay(200);
	LED0=~LED0;				//����ȥ��
	ADCResult[0] = ADC0L;
	ADCResult[1] = ADC0M;
	ADCResult[2] = ADC0H;
    adc = ADCResult[2]*256*256 + ADCResult[1]*256 + ADCResult[0];
	B_AD = adc*10000/(I*Kh);		//����Ҫת���ɵ�ѹֵ,  �������� 
	//���������ǰѸ�����ת��Ϊ6λ������,ͬʱȷ��С�����λ��,�������
/*	if(B_AD>99999)			
		channel=0;		//С���������λ���Ժ���
	else if (B_AD>9999)
		{
			channel=1;
			B_AD = B_AD*10;
		}
	else if(B_AD>999)
		{
			channel=2;
			B_AD=B_AD*100;
		}
	else if(B_AD>99)
		{
			channel=3;
			B_AD=B_AD*1000;
		}   
	else if(B_AD>9)
		{
			channel=4;
			B_AD=B_AD*10000;
		}   
	else if(B_AD * 10 > 9)
		{
			channel=5;
			B_AD=B_AD*100000;
		}   
	else 
	{
		channel=5;
		B_AD=B_AD*100000;
	}
    AD0INT=0;*/
    
}
//-----------------------------------------------------------------------------
// SYSCLK_Init
//-----------------------------------------------------------------------------
//
// This routine initializes the system clock to use the internal 24.5MHz / 8 
// oscillator as its clock source.  Also enables missing clock detector reset.
//
void SYSCLK_Init (void)
{
	 OSCICN = 0x83;                         // configure internal oscillator 24.5MHz     (OSCICN:�ڲ��������ƼĴ���) ox83Ϊ�ڲ���������  �����������Ƶ                           // its lowest frequency
	 RSTSRC = 0x04;                         // enable missing clock detector             (RSTSRC:��λԴ�Ĵ���)
	 PFE0CN = 0x20;   						//ָ��Ԥȡʹ��
}

void ADC_Init()
{
	ADC0MD=0x81;							//�ɽ���У׼��ת������ȫ���ڲ�У׼��
	while(~AD0CALC)
	{
	}
    //ADC0CN    = 0x07;                     //128��
    ADC0CN=0x05;							//һ�������ѹ�źŽ�С������ѡ��Ŵ�32��.   ADC0CN�����ƼĴ���(���ƷŴ����汶��)
    //  ADC0MD    = 0x80;                      //ADC ʹ��,
    ADC0CLK   = 0x09;                       //������ʱ�ӷ�Ƶ�Ĵ���
    ADC0MUX   = 0x38;						//AIN0.3��Ϊ������,������ӵ�      ģ���·�����ƼĴ���
	// ADC0MUX =0x08;						//�ڲ��ӵ�
	ADC0DAC=0x80;							//λ7��ʾ����λ��0=����1=��      ADC0DAC:ADC0ƫ��DAC���־�
//	ADC0MD = 0x83;							//����ת��
}


//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Configure the Crossbar and GPIO ports.
// P3.3 - LED (push-pull)
//
void PORT_Init (void)
{
    P0MDOUT   = 0xFF;
    P0SKIP    = 0xFF;	//ȫ������������,��Ϊ8λ����ܵ�����
    P1MDIN    = 0x3F;   
    P1MDOUT   = 0xFF;
    P1SKIP    = 0xFF;
    XBR1      = 0x40;    
    //P1SKIP    = 0xC0;           //1.7 1.6 Ϊģ�����룬Ӧ����
	//P0SKIP = 0x30;           //���� 0.4 0.5 ��?
 //   XBR0      = 0x01;           //UART TX0,RX0�����˿�����P0.4 ��P0.5
    XBR1      = 0x40;           //���濪��ʹ��


}

//-----------------------------------------------------------------------------
// Interrupt Service Routines
//-----------------------------------------------------------------------------

void DAC_Init()
{
    IDA0CN    = 0xFB;
}

void Interrupts_Init()
{
    EIE1      = 0x28;                  //����Ƚ����жϺ�ADC�ж�
    EIP1      = 0x20;                  //�Ƚ������ȼ���
    IE        = 0x80;
}



void delay(int time)
{
	char i, j;
	while(time>1)
	{
		for(i=0; i<500; i++)
		{
			for(j=0; j<500; j++);
		}
		time--;
	}
}